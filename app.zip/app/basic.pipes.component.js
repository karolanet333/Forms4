"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var BasicPipesComponent = (function () {
    function BasicPipesComponent() {
        this.course = {
            title: "Angular2 for Begginers",
            rating: 4.9745,
            students: 5981,
            price: 99.95,
            releaseDate: new Date(2016, 3, 2),
            description: "A powerful VS Code debugging feature is the ability to set conditions either based on expressions or hit counts. When you create a new breakpoint, you have the option to Add Breakpoint or a Add Conditional Breakpoint. If you add a conditional breakpoint, you have a dropdown to choose either an Expression or Hit Count condition."
        };
    }
    BasicPipesComponent = __decorate([
        core_1.Component({
            selector: 'basic-pipes',
            template: "\n        Course Title: {{course.title | uppercase | lowercase}}\n        <br/>\n        Students: {{course.students | number}}\n        <br/>\n        Rating: {{course.rating | number}}\n        <br/>\n        Course Price: {{course.price | currency:'ARS':true:'2.2-2'}}\n        <br/>\n        Release Date: {{course.releaseDate | date:'dd/MM/yyyy'}}\n        <br/>\n        {{course | json}}\n        <br/>\n        Description: {{course.description | summary:10}}\n    "
        }), 
        __metadata('design:paramtypes', [])
    ], BasicPipesComponent);
    return BasicPipesComponent;
}());
exports.BasicPipesComponent = BasicPipesComponent;
//# sourceMappingURL=basic.pipes.component.js.map
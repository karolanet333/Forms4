import {Component} from '@angular/core'

@Component({
    'selector': 'zippy',
    template:`

    `
})
export class ZippyComponent{
    
}
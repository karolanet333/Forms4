

export class Zippy{
    title: string;
    html: string;
}
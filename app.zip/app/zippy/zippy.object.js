"use strict";
var Zippy = (function () {
    function Zippy() {
    }
    return Zippy;
}());
exports.Zippy = Zippy;
//# sourceMappingURL=zippy.object.js.map
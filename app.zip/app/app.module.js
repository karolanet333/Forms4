"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var forms_1 = require('@angular/forms');
var core_2 = require('@angular/core');
var app_component_1 = require('./app.component');
var basic_pipes_component_1 = require('./basic.pipes.component');
var bs_panel_component_1 = require('./bs.panel.component');
var zippy_unit_component_1 = require('./zippy/zippy.unit.component');
var contact_form_component_1 = require('./basic-form/contact-form.component');
var auto_grow_directive_1 = require('./auto-grow.directive');
var highlight_directive_1 = require('./highlight.directive');
var summary_pipe_1 = require('./summary.pipe');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_browser_1.BrowserModule,
                forms_1.FormsModule
            ],
            declarations: [
                //StartupComponent
                app_component_1.AppComponent,
                //Components
                basic_pipes_component_1.BasicPipesComponent,
                bs_panel_component_1.BsPanelComponent,
                zippy_unit_component_1.ZippyUnitComponent,
                contact_form_component_1.ContactFormComponent,
                //Attribute Directives
                auto_grow_directive_1.AutoGrowDirective,
                highlight_directive_1.HighlightDirective,
                //Pipes
                summary_pipe_1.SummaryPipe
            ],
            bootstrap: [
                app_component_1.AppComponent
            ],
            providers: [
                { provide: core_2.LOCALE_ID, useValue: "es-AR" }
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map
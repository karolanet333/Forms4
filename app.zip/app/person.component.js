"use strict";
var PersonComponent = (function () {
    function PersonComponent() {
    }
    return PersonComponent;
}());
exports.PersonComponent = PersonComponent;
//# sourceMappingURL=person.component.js.map